import * as React from 'react';
import Box from '@mui/material/Box';

const header = () => {
    return <>
   <Box bgcolor={"primary.main"}> 
<div style={{width: '300' , height: '300'  }}>
<h1> hihi</h1>
</div>


</Box>
</>;
 
};

export default  header;