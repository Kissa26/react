import React from "react";
import Info from "../Components/Info";
import Stack from '@mui/material/Stack';

const Landing = () => {
    return (
    <>
    <Info />
  
    </>
    );
  }
  export default Landing;