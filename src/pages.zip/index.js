import * as React from 'react';
import ReactDOM from 'react-dom';
import Landing from "./pages/Landing";
import { BrowserRouter, Routes, Route } from "react-router-dom";


ReactDOM.render(

  <React.StrictMode>
    <BrowserRouter>
      <Routes>
       
        <Route index element={<Landing />} />
       
      </Routes>
    </BrowserRouter>
  </React.StrictMode>,
    document.getElementById("root")

);